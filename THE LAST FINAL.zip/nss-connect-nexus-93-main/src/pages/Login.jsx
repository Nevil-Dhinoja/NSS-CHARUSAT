
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const Login = () => {
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [userType, setUserType] = useState("pc");
  const [isLoading, setIsLoading] = useState(false);
  
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!loginId || !password) {
      toast({
        title: "Error",
        description: "Please enter both login ID and password.",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      
      localStorage.setItem("nssUserToken", "mock-token");
      localStorage.setItem("nssUserRole", userType);
      localStorage.setItem("nssUserName", userType === "pc" ? "Dr. Sharma" : 
                                          userType === "po" ? "Prof. Patel" : 
                                          "Ravi Kumar");
      localStorage.setItem("nssUserEmail", userType === "pc" ? "director@nss.edu" : 
                                           userType === "po" ? "officer@nss.edu" : 
                                           "student@nss.edu");
      
      toast({
        title: "Success",
        description: "Login successful. Redirecting...",
      });
      
      navigate("/dashboard");
    }, 1500);
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 mb-8 border border-white/20">
            <h1 className="text-4xl font-bold mb-3 text-white">NSS Connect</h1>
            <p className="text-blue-100 text-lg">National Service Scheme Portal</p>
          </div>
        </div>
        
        <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0 rounded-3xl overflow-hidden">
          <CardHeader className="text-center pb-4 pt-8 px-8">
            <CardTitle className="text-3xl font-bold text-gray-900 mb-2">Welcome Back</CardTitle>
            <CardDescription className="text-gray-600 text-lg">Sign in to access your NSS Connect account</CardDescription>
          </CardHeader>
          
          <CardContent className="p-8 pt-4">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-3">
                <Label htmlFor="userType" className="text-gray-700 font-semibold text-base">Login As</Label>
                <Select value={userType} onValueChange={(value) => setUserType(value)}>
                  <SelectTrigger className="h-14 rounded-xl border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 bg-gray-50 focus:bg-white transition-all duration-200 text-base">
                    <SelectValue placeholder="Select user type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pc">Program Coordinator</SelectItem>
                    <SelectItem value="po">Program Officer</SelectItem>
                    <SelectItem value="sc">Student Coordinator</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-3">
                <Label htmlFor="loginId" className="text-gray-700 font-semibold text-base">Login ID</Label>
                <Input
                  id="loginId"
                  placeholder={userType === "pc" ? "Program Coordinator ID" : 
                                userType === "po" ? "Employee Number" : 
                                "Student ID Number"}
                  value={loginId}
                  onChange={(e) => setLoginId(e.target.value)}
                  required
                  className="h-14 rounded-xl border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 bg-gray-50 focus:bg-white transition-all duration-200 text-base px-4"
                />
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <Label htmlFor="password" className="text-gray-700 font-semibold text-base">Password</Label>
                  <a href="/forgot-password" className="text-sm text-blue-600 hover:text-blue-700 hover:underline font-medium">
                    Forgot password?
                  </a>
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="h-14 rounded-xl border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 bg-gray-50 focus:bg-white transition-all duration-200 text-base px-4"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full h-14 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-200 mt-8"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                    <span>Signing in...</span>
                  </div>
                ) : (
                  "Sign in"
                )}
              </Button>
            </form>
            
            <div className="text-center mt-8 text-sm text-gray-500">
              <p>&copy; {new Date().getFullYear()} NSS Connect. All rights reserved.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Login;
