
import React, { useEffect, useState } from "react";
import DashboardLayout from "../../components/DashboardLayout";
import ProgramCoordinatorDashboard from "./ProgramCoordinatorDashboard";
import ProgramOfficerDashboard from "./ProgramOfficerDashboard";
import StudentCoordinatorDashboard from "./StudentCoordinatorDashboard";

const Dashboard = () => {
  const [userRole, setUserRole] = useState(null);
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem("nssUserToken");
    if (!token) {
      window.location.href = "/login";
      return;
    }
    
    // Get user role from localStorage
    const role = localStorage.getItem("nssUserRole");
    const name = localStorage.getItem("nssUserName") || "";
    const email = localStorage.getItem("nssUserEmail") || "";
    
    setUserRole(role);
    setUserName(name);
    setUserEmail(email);
  }, []);

  if (!userRole) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="text-lg mt-4">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  // Render appropriate dashboard based on user role, wrapped with DashboardLayout
  const renderDashboardContent = () => {
    switch (userRole) {
      case "pc":
        return <ProgramCoordinatorDashboard userRole={userRole} userName={userName} userEmail={userEmail} />;
      case "po":
        return <ProgramOfficerDashboard userRole={userRole} userName={userName} userEmail={userEmail} />;
      case "sc":
        return <StudentCoordinatorDashboard userRole={userRole} userName={userName} userEmail={userEmail} />;
      default:
        return (
          <div className="min-h-screen flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
              <p className="text-gray-600 mt-2">Invalid user role</p>
            </div>
          </div>
        );
    }
  };

  return (
    <DashboardLayout userRole={userRole} userName={userName} userEmail={userEmail}>
      {renderDashboardContent()}
    </DashboardLayout>
  );
};

export default Dashboard;
