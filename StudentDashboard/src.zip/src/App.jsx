
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Volunteers from './pages/Volunteers'
import Profile from './pages/Profile'
import Nav from './components/Nav'
import Com from './pages/Com'


function App() {
  return (
    <div>
    

      <Com/>
      
     
    

      
    </div>
  )
}

export default App
